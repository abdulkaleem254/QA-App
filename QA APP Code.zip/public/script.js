// check function
function checkProperty() {
    const url = document.getElementById("inputField").value;
    // Show loading spinner
    document.getElementById("loading").style.display = "block";
    // sending url to nodejs to fetch properties
    sendNodejs(url);
}


// function to send url to node file
function sendNodejs(url) {
    fetch('/kaleem',{
        method : 'POST',
        headers : {
            'Content-Type':'application/json',
        },
        body: JSON.stringify({url:url}),
    }).then(res => {
        if(res.ok) {
            console.log("data get successfully");
            return res.json();
        } else {
            console.error('Failed to send data');
        }
    }).then(data => {
        if(data) {
            const pageAttribute = data;
            // Hide loading spinner
            document.getElementById("loading").style.display = "none";
            document.getElementById("output-box").style.display = "block";
            // sending page attribute to a function to display
            sendingObject(pageAttribute);
        } else {
            document.getElementById("loading").style.display = "none";
            console.error("Received data is undefined or does not have 'gettedvalue'");
        }
    }).catch(err => {
        document.getElementById("loading").style.display = "none";
        console.log("error :" ,err);
    });
}


// function to display result got from nodejs file
function sendingObject(obj) {
    console.log(obj);
    const pageProperty = obj.gettedvalue.dataLayerAttributes;
    console.log(pageProperty);
    var results=document.getElementById("results");
    results.innerHTML=`<div class="row-value scale-up-center">
                        <p class="fw-bold">Property</p>
                        <p class="fw-bold">Property value</p>
                        <p class="fw-bold">Status</p>
                    </div>`;

    document.getElementById("templateName").innerText=keycamelCase(pageProperty["pageTemplate"]);

    var mandatoryFields = ["pageTemplate", "pageTitle", "description", "authors","primarySubject", "secondarySubject", "contentState", "thumbnailUrl", "siteSection"];
    mandatoryFields.forEach(field => {
        console.log(field);
        for(var key in pageProperty) {
            if(key == field) {

                var div=document.createElement("div");
                div.classList.add("row-value");
                
                var ptitles=document.createElement("p");
                ptitles.classList.add("fw-bold");
                var pprop=document.createElement("p");
                var pstatus=document.createElement("p");
                

                if(pageProperty[key].trim() !== '') {
                    pstatus.classList.add("text-success");
                    pstatus.innerHTML += '<p class="fw-bold">Ok <i class="fa-solid fa-check-circle"></i></p>'; // Green check icon
                } else {
                    pstatus.classList.add("fw-bold","text-danger");
                    pstatus.innerHTML += '<p>Error <i class="fa-solid fa-circle-exclamation"></i></p>'; // Red alert icon
                }
                ptitles.innerText=keycamelCase(key);
                pprop.innerText=pageProperty[key];
                div.appendChild(ptitles);
                div.appendChild(pprop);
                div.appendChild(pstatus);
                results.appendChild(div);

            }
        }
    }); 
}


// function to convert the title to title case
function keycamelCase(str)
{
    let newStr=str.replace(/([a-z])([A-Z])/g,'$1 $2');
    newStr=newStr.split('');
    newStr[0]=newStr[0].toUpperCase();
    return newStr.join('');
}

// function to show only properties tab
function properties()
{
    document.getElementById("property-tab").classList.add("active");
    document.getElementById("page-tab").classList.remove("active");

}
function page()
{
    document.getElementById("property-tab").classList.remove("active");
    document.getElementById("page-tab").classList.add("active");

}

