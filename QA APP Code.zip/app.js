// const express = require('express');
// const puppeteer = require('puppeteer');
// app = express();
// app.use(express.static('public'))
// const bodyParser = require('body-parser');
// app.use(bodyParser.json());



// app.post('/', async (req, res) => {
//     try {
//         console.log("Program is running, fetching page data...");
//         const receivedData = req.body.url;
//         console.log("Received data is ", receivedData)
//         const gettedvalue = await getPuppeteervalue(receivedData);
//         console.log(gettedvalue);
//         res.status(200).json({ gettedvalue });
//     }
//     catch (error) {
//         console.error("Error:", error);
//         res.status(500).send("Internal Server Error");
//     }
// })

// async function getPuppeteerValue(url) {
//     const browser = await puppeteer.launch();
//     const page = await browser.newPage();
//     await page.goto(url, { waitUntil: 'domcontentloaded' });

//     // Extract data from dataLayer.page
//     const dataLayerAttributes = await page.evaluate(() => {
//         return JSON.stringify(dataLayer.page.attributes);
//     });

//     // Extract content from <meta> tags
//     // const ogMetaTags = await page.evaluate(() => {
//     //     const metaTags = document.querySelectorAll('meta[property^="og:"]');
//     //     const ogMetaTagsArray = Array.from(metaTags).map(tag => ({
//     //         property: tag.getAttribute('property'),
//     //         content: tag.getAttribute('content')
//     //     }));
//     //     return ogMetaTagsArray;
//     // });

//     await browser.close();
//     return dataLayerAttributes;

//     // Combine both sets of data into one object
//     // const result = {
//     //     dataLayerAttributes: dataLayerAttributes,
//     //     ogMetaTags: ogMetaTags
//     // };

//     // return result;
// }



// app.listen(8080, () => {
//     console.log("server is running");
// });


// const functions = require('firebase-functions');

const express = require('express');
const puppeteer = require('puppeteer');
const path = require('path');

const appExpress = express();
appExpress.use(express.static('public'));
const bodyParser = require('body-parser');
appExpress.use(bodyParser.json());

appExpress.post('/kaleem', async (req, res) => {
    try {
        console.log("Program is running, fetching page data...");
        const receivedData = req.body.url;
        console.log("Received data is ", receivedData);
        const gettedvalue = await getPuppeteerValue(receivedData);
        console.log(gettedvalue);
        res.status(200).json({ gettedvalue });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).send("Internal Server Error");
    }
});


async function getPuppeteerValue(url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    const myproperty = await page.evaluate(() => {
        return dataLayer.page.attributes;
    });
    // Extract content from <meta> tags
    const ogMetaTags = await page.evaluate(() => {
        const metaTags = document.querySelectorAll('meta[property^="og:"]');
        const ogMetaTagsArray = Array.from(metaTags).map(tag => ({
            property: tag.getAttribute('property'),
            content: tag.getAttribute('content')
        }));
        return ogMetaTagsArray;
    });

    // checking for in-page navigation
    const inPageNav=await page.evaluate(()=>{
        return !!document.querySelector('div[class="cmp-in-page-nav__section cmp-in-page-nav__section--buttons"]');
        
    })
    
    
    // checking for empty components
    const emptyComponents = await page.evaluate(()=>{
        const emptyelements=[];
        const elements=document.querySelectorAll('.container responsivegrid content-width-1400--with-padding aem-GridColumn aem-GridColumn--default--12');
        elements.forEach(ele=>{
            if(!ele.textContent.trim() && !ele.children.length)
            {
                emptyComponents.push(ele);
            }
        });
        return emptyelements;
    })


    // checking for breadcrumbs
    const breadcrumbs=await page.evaluate(()=>{
        return !!document.querySelector(`div[class="cmp-breadcrumbs__container"]`);
    })

    // Combine both sets of data into one object
    const result = {
        dataLayerAttributes: myproperty,
        ogMetaTags: ogMetaTags,
        inPageNav: inPageNav,
        emptyELements : emptyComponents,
        breadcrumbs : breadcrumbs
    };
    

    await browser.close();
    return result;
}


appExpress.listen(8080, () => {
    console.log("Express server is running on port 8080");
});


// promo container class
// promocontainerv2 cmp-promo-container aem-GridColumn--tablet--10 aem-GridColumn--offset--tablet--1 
// aem-GridColumn--phone--12 aem-GridColumn--offset--phone--0 aem-GridColumn aem-GridColumn--default--12
// Breadcrumbs class - cmp-breadcrumbs__container