const { app, BrowserWindow } = require('electron');
const path = require('path');
// const express = require('express');
// const bodyParser = require('body-parser');
// const puppeteer = require('puppeteer');

// Initialize Express app
// const expressApp = express();
// expressApp.use(express.static('public'));// expressApp.use(bodyParser.json());

// Define routes
// expressApp.post('/', async (req, res) => {
//     try {
//         console.log("Program is running, fetching page data...");
//         const receivedData = req.body.url;
//         console.log("Received data is ", receivedData)
//         const gettedvalue = await getPuppeteerValue(receivedData);
//         console.log(gettedvalue);
//         res.status(200).json({ gettedvalue });
//     } catch (error) {
//         console.error("Error:", error);
//         res.status(500).send("Internal Server Error");
//     }
// });

// async function getPuppeteerValue(url) {
//     const browser = await puppeteer.launch();
//     const page = await browser.newPage();
//     await page.goto(url, { waitUntil: 'domcontentloaded' });
//     const myproperty = await page.evaluate(() => {
//         return JSON.stringify(dataLayer.page.attributes)
//     });
//     await browser.close();
//     return myproperty;
// }

// expressApp.listen(8080, () => {
//     console.log("Server is running on port 8080");
// });

// Electron app initialization
app.whenReady().then(() => {
    const mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
    });

    mainWindow.loadFile(path.join('./public/index.html'));
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
